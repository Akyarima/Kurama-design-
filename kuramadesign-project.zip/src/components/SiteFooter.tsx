import { Link } from "@tanstack/react-router";
import { Phone, Mail, MapPin, MessageCircle, Globe, Facebook } from "lucide-react";
import logo from "@/assets/kurama-logo-transparent.png";

export function SiteFooter() {
  return (
    <footer className="mt-24 bg-primary text-primary-foreground">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 md:grid-cols-4 md:px-6">
        <div className="md:col-span-2">
          <div className="inline-flex items-center rounded-lg bg-primary-foreground/95 px-3 py-2">
            <img
              src={logo}
              alt="Kurama Interior & Exterior Finishing logo"
              className="h-14 w-auto"
            />
          </div>
          <p className="mt-4 max-w-md text-sm text-primary-foreground/70">
            Professional interior and exterior finishing across Nigeria. Wall
            screeding, POP ceilings, painting, wallpaper, and complete building
            finishing — delivered clean, durable, and on time.
          </p>
        </div>

        <div>
          <h4 className="text-sm font-bold uppercase tracking-wider text-accent">Services</h4>
          <ul className="mt-4 space-y-2 text-sm text-primary-foreground/80">
            <li><Link to="/services" className="hover:text-accent">Wall Screeding</Link></li>
            <li><Link to="/services" className="hover:text-accent">POP Ceiling Installation</Link></li>
            <li><Link to="/services" className="hover:text-accent">Painting</Link></li>
            <li><Link to="/services" className="hover:text-accent">Wallpaper Installation</Link></li>
            <li><Link to="/services" className="hover:text-accent">General Finishing</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-sm font-bold uppercase tracking-wider text-accent">Contact</h4>
          <ul className="mt-4 space-y-3 text-sm text-primary-foreground/80">
            <li className="flex items-start gap-2">
              <Phone className="mt-0.5 h-4 w-4 text-accent" />
              <a href="tel:+2347084772196" className="hover:text-accent hover:underline">0708 477 2196</a>
            </li>
            <li className="flex items-start gap-2">
              <MessageCircle className="mt-0.5 h-4 w-4 text-accent" />
              <a href="https://wa.me/2347084772196" target="_blank" rel="noopener noreferrer" className="hover:text-accent hover:underline">WhatsApp</a>
            </li>
            <li className="flex items-start gap-2">
              <Globe className="mt-0.5 h-4 w-4 text-accent" />
              <a href="http://kuramadesign.name.ng/" target="_blank" rel="noopener noreferrer" className="hover:text-accent hover:underline">kuramadesign.name.ng</a>
            </li>
            <li className="flex items-start gap-2">
              <Facebook className="mt-0.5 h-4 w-4 text-accent" />
              <a href="https://www.facebook.com/kuramadesign" target="_blank" rel="noopener noreferrer" className="hover:text-accent hover:underline">facebook.com/kuramadesign</a>
            </li>
            <li className="flex items-start gap-2">
              <Mail className="mt-0.5 h-4 w-4 text-accent" />
              <a href="mailto:kurama1655@gmail.com" className="hover:text-accent hover:underline">kurama1655@gmail.com</a>
            </li>
            <li className="flex items-start gap-2">
              <MapPin className="mt-0.5 h-4 w-4 text-accent" />
              <span>Serving all states in Nigeria</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-primary-foreground/10">
        <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-2 px-4 py-5 text-xs text-primary-foreground/60 md:flex-row md:items-center md:px-6">
          <p>© {new Date().getFullYear()} Kurama Interior & Exterior Finishing. All rights reserved.</p>
          <p>Built with craftsmanship.</p>
        </div>
      </div>
    </footer>
  );
}