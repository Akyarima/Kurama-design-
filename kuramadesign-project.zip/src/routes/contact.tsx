import { createFileRoute } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { Phone, Mail, MapPin, MessageCircle, CheckCircle2, Globe, Facebook } from "lucide-react";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Kurama Interior & Exterior Finishing" },
      {
        name: "description",
        content:
          "Get a quote for wall screeding, POP ceilings, painting, wallpaper, or full building finishing. Serving all states in Nigeria.",
      },
      { property: "og:title", content: "Contact Kurama Finishing" },
      {
        property: "og:description",
        content: "Request a quote or talk to our finishing team across Nigeria.",
      },
      { property: "og:url", content: "/contact" },
    ],
    links: [{ rel: "canonical", href: "/contact" }],
  }),
  component: ContactPage,
});

function ContactPage() {
  const [sent, setSent] = useState(false);

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSent(true);
  }

  return (
    <div>
      <section className="border-b border-border bg-secondary">
        <div className="mx-auto max-w-7xl px-4 py-16 md:px-6 md:py-24">
          <p className="text-sm font-bold uppercase tracking-[0.2em] text-accent">Contact</p>
          <h1 className="mt-2 text-4xl font-black tracking-tight text-foreground md:text-5xl">
            Let's talk about your space.
          </h1>
          <p className="mt-4 max-w-2xl text-muted-foreground">
            Send us a quick message about your project. We'll reach out with a
            clear plan and a quote you can trust.
          </p>
        </div>
      </section>

      <section className="mx-auto grid max-w-7xl gap-10 px-4 py-16 md:grid-cols-5 md:px-6 md:py-20">
        <div className="md:col-span-2">
          <h2 className="text-xl font-black text-foreground">Reach us directly</h2>
          <ul className="mt-6 space-y-5 text-sm">
            <li className="flex items-start gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-md bg-accent/15 text-accent">
                <Phone className="h-5 w-5" />
              </span>
              <div>
                <p className="font-bold text-foreground">Call us</p>
                <a href="tel:+2347084772196" className="text-muted-foreground hover:text-accent hover:underline">0708 477 2196</a>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-md bg-accent/15 text-accent">
                <MessageCircle className="h-5 w-5" />
              </span>
              <div>
                <p className="font-bold text-foreground">WhatsApp</p>
                <a href="https://wa.me/2347084772196" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-accent hover:underline">0708 477 2196</a>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-md bg-accent/15 text-accent">
                <Globe className="h-5 w-5" />
              </span>
              <div>
                <p className="font-bold text-foreground">Website</p>
                <a href="http://kuramadesign.name.ng/" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-accent hover:underline">kuramadesign.name.ng</a>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-md bg-accent/15 text-accent">
                <Facebook className="h-5 w-5" />
              </span>
              <div>
                <p className="font-bold text-foreground">Facebook</p>
                <a href="https://www.facebook.com/kuramadesign" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-accent hover:underline">facebook.com/kuramadesign</a>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-md bg-accent/15 text-accent">
                <Mail className="h-5 w-5" />
              </span>
              <div>
                <p className="font-bold text-foreground">Email</p>
                <a href="mailto:kurama1655@gmail.com" className="text-muted-foreground hover:text-accent hover:underline">kurama1655@gmail.com</a>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-md bg-accent/15 text-accent">
                <MapPin className="h-5 w-5" />
              </span>
              <div>
                <p className="font-bold text-foreground">Service area</p>
                <p className="text-muted-foreground">All states across Nigeria</p>
              </div>
            </li>
          </ul>
        </div>

        <div className="md:col-span-3">
          <div className="rounded-2xl border border-border bg-card p-6 md:p-8">
            {sent ? (
              <div className="flex flex-col items-center gap-3 py-12 text-center">
                <span className="flex h-12 w-12 items-center justify-center rounded-full bg-accent/20 text-accent">
                  <CheckCircle2 className="h-6 w-6" />
                </span>
                <h3 className="text-xl font-black text-card-foreground">Thanks — message received.</h3>
                <p className="max-w-sm text-sm text-muted-foreground">
                  We'll be in touch shortly with the next steps for your project.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="grid gap-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <Field label="Full name" name="name" required />
                  <Field label="Phone" name="phone" type="tel" required />
                </div>
                <Field label="Email" name="email" type="email" required />
                <Field label="Location / State" name="location" required />
                <div>
                  <label htmlFor="service" className="text-sm font-semibold text-foreground">
                    Service needed
                  </label>
                  <select
                    id="service"
                    name="service"
                    className="mt-1 w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                  >
                    <option>Wall Screeding</option>
                    <option>POP Ceiling Installation</option>
                    <option>Painting</option>
                    <option>Wallpaper Installation</option>
                    <option>General Building Finishing</option>
                    <option>Not sure yet</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="message" className="text-sm font-semibold text-foreground">
                    Project details
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    rows={5}
                    required
                    placeholder="Tell us about your space and timeline..."
                    className="mt-1 w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                  />
                </div>
                <button
                  type="submit"
                  className="mt-2 inline-flex items-center justify-center rounded-md bg-accent px-6 py-3 text-sm font-bold text-accent-foreground hover:scale-[1.01] transition-transform"
                >
                  Send Message
                </button>
              </form>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}

function Field({
  label,
  name,
  type = "text",
  required,
}: {
  label: string;
  name: string;
  type?: string;
  required?: boolean;
}) {
  return (
    <div>
      <label htmlFor={name} className="text-sm font-semibold text-foreground">
        {label}
      </label>
      <input
        id={name}
        name={name}
        type={type}
        required={required}
        className="mt-1 w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
      />
    </div>
  );
}