import { createFileRoute, Link } from "@tanstack/react-router";
import { Quote, Star, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/testimonials")({
  head: () => ({
    meta: [
      { title: "Testimonials — Kurama Finishing Clients" },
      {
        name: "description",
        content:
          "What homeowners, contractors, and businesses say about working with Kurama Interior & Exterior Finishing.",
      },
      { property: "og:title", content: "Testimonials — Kurama Finishing" },
      { property: "og:description", content: "Real client feedback on our finishing projects." },
      { property: "og:url", content: "/testimonials" },
    ],
    links: [{ rel: "canonical", href: "/testimonials" }],
  }),
  component: TestimonialsPage,
});

const testimonials = [
  {
    quote:
      "Kurama handled the screeding and POP ceiling for our new home. The finishing was incredibly clean and they delivered on time — we will use them again.",
    name: "Adaeze O.",
    role: "Homeowner",
    location: "Lagos",
  },
  {
    quote:
      "We've worked with several finishing teams on projects across Nigeria. The Kurama crew stands out for their preparation and how neat the site is left every day.",
    name: "Engr. Tunde A.",
    role: "Building Contractor",
    location: "Abuja",
  },
  {
    quote:
      "The interior painting and wallpaper work on our restaurant was flawless. Customers compliment the space constantly.",
    name: "Chinedu M.",
    role: "Restaurant Owner",
    location: "Enugu",
  },
  {
    quote:
      "Professional from start to finish. They explained the process, kept to the budget, and the wall finish is still perfect two years later.",
    name: "Mrs. Bello",
    role: "Homeowner",
    location: "Ibadan",
  },
  {
    quote:
      "Hired Kurama to finish two duplexes — exterior painting and full interior. Quality and consistency across both buildings was impressive.",
    name: "Real Estate Developer",
    role: "Property Developer",
    location: "Port Harcourt",
  },
  {
    quote:
      "Our office renovation looks completely transformed. The POP ceiling design they recommended fits the space perfectly.",
    name: "Funmi K.",
    role: "Office Manager",
    location: "Lagos",
  },
];

function TestimonialsPage() {
  return (
    <div>
      <section className="border-b border-border bg-secondary">
        <div className="mx-auto max-w-7xl px-4 py-16 md:px-6 md:py-24">
          <p className="text-sm font-bold uppercase tracking-[0.2em] text-accent">Testimonials</p>
          <h1 className="mt-2 text-4xl font-black tracking-tight text-foreground md:text-5xl">
            Trusted by homeowners, contractors, and businesses.
          </h1>
          <p className="mt-4 max-w-2xl text-muted-foreground">
            We measure success by what our clients say after the project is done.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 md:px-6 md:py-20">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((t) => (
            <figure
              key={t.name + t.location}
              className="flex flex-col rounded-2xl border border-border bg-card p-6"
            >
              <Quote className="h-7 w-7 text-accent" />
              <blockquote className="mt-3 flex-1 text-sm leading-relaxed text-card-foreground">
                "{t.quote}"
              </blockquote>
              <div className="mt-5 flex items-center gap-1 text-accent">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-current" />
                ))}
              </div>
              <figcaption className="mt-3 border-t border-border pt-4">
                <p className="text-sm font-bold text-card-foreground">{t.name}</p>
                <p className="text-xs text-muted-foreground">
                  {t.role} · {t.location}
                </p>
              </figcaption>
            </figure>
          ))}
        </div>

        <div className="mt-14 flex flex-col items-center gap-4 rounded-2xl bg-primary p-10 text-center text-primary-foreground">
          <h3 className="text-2xl font-black md:text-3xl">Join our happy clients.</h3>
          <Link
            to="/contact"
            className="inline-flex items-center gap-2 rounded-md bg-accent px-6 py-3 text-sm font-bold text-accent-foreground"
          >
            Start Your Project <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>
    </div>
  );
}