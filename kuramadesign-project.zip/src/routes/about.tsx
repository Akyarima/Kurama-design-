import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Target, Heart, Award, MapPin } from "lucide-react";
import heroImage from "../assets/hero-interior.jpg";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Kurama Interior & Exterior Finishing" },
      {
        name: "description",
        content:
          "Kurama Interior & Exterior Finishing delivers professional finishing services across Nigeria — quality, neat workmanship, and on-time delivery.",
      },
      { property: "og:title", content: "About — Kurama Finishing" },
      {
        property: "og:description",
        content: "Who we are and how we work on every finishing project.",
      },
      { property: "og:url", content: "/about" },
    ],
    links: [{ rel: "canonical", href: "/about" }],
  }),
  component: AboutPage,
});

const values = [
  { icon: Award, title: "Quality first", desc: "We don't cut corners — every finish is built to last." },
  { icon: Heart, title: "Neat workmanship", desc: "Clean lines, clean edges, clean site at the end of every day." },
  { icon: Target, title: "Timely delivery", desc: "We respect your schedule and deliver when we say we will." },
  { icon: MapPin, title: "Nationwide service", desc: "Available on-site across all states in Nigeria." },
];

function AboutPage() {
  return (
    <div>
      <section className="border-b border-border bg-secondary">
        <div className="mx-auto grid max-w-7xl gap-10 px-4 py-16 md:grid-cols-2 md:px-6 md:py-24">
          <div>
            <p className="text-sm font-bold uppercase tracking-[0.2em] text-accent">About Kurama</p>
            <h1 className="mt-2 text-4xl font-black tracking-tight text-foreground md:text-5xl">
              A finishing company built on craftsmanship.
            </h1>
            <p className="mt-5 text-muted-foreground">
              Kurama Interior & Exterior Finishing provides professional
              finishing services across Nigeria. We specialize in wall
              screeding, POP ceiling installation, painting, wallpaper
              installation, and general building finishing — delivering clean,
              durable, high-quality work that improves the beauty and value of
              every space we work on.
            </p>
            <p className="mt-4 text-muted-foreground">
              We work with homeowners, contractors, and businesses, offering
              reliable services both on-site and across different states in
              Nigeria. Customer satisfaction, neat finishing, and timely
              project delivery are our top priorities.
            </p>
          </div>
          <div className="overflow-hidden rounded-2xl">
            <img
              src={heroImage}
              alt="Interior finishing by Kurama"
              loading="lazy"
              className="h-full w-full object-cover"
            />
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 md:px-6 md:py-20">
        <p className="text-sm font-bold uppercase tracking-[0.2em] text-accent">Our values</p>
        <h2 className="mt-2 text-3xl font-black tracking-tight text-foreground md:text-4xl">
          What guides every project.
        </h2>
        <div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {values.map(({ icon: Icon, title, desc }) => (
            <div key={title} className="rounded-xl border border-border bg-card p-6">
              <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-accent/15 text-accent">
                <Icon className="h-5 w-5" />
              </span>
              <h3 className="mt-4 text-lg font-extrabold text-card-foreground">{title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 pb-16 md:px-6">
        <div className="overflow-hidden rounded-2xl bg-primary p-10 text-primary-foreground md:p-14">
          <div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-center">
            <div>
              <h2 className="text-2xl font-black tracking-tight md:text-3xl">
                Let's finish your project right.
              </h2>
              <p className="mt-2 text-primary-foreground/70">
                From a single room to a full building — we'd love to help.
              </p>
            </div>
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 rounded-md bg-accent px-6 py-3 text-sm font-bold text-accent-foreground"
            >
              Get in Touch <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}