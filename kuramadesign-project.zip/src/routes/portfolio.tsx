import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowRight } from "lucide-react";
import project1 from "../assets/project-1.jpg";
import project2 from "../assets/project-2.jpg";
import project3 from "../assets/project-3.jpg";
import project4 from "../assets/project-4.jpg";
import project5 from "../assets/project-5.jpg";
import project6 from "../assets/project-6.jpg";

export const Route = createFileRoute("/portfolio")({
  head: () => ({
    meta: [
      { title: "Portfolio — Kurama Finishing Projects" },
      {
        name: "description",
        content:
          "Recent interior and exterior finishing projects by Kurama: POP ceilings, painting, screeding, and wallpaper installations across Nigeria.",
      },
      { property: "og:title", content: "Portfolio — Kurama Finishing" },
      {
        property: "og:description",
        content: "A selection of recent finishing projects across Nigeria.",
      },
      { property: "og:url", content: "/portfolio" },
    ],
    links: [{ rel: "canonical", href: "/portfolio" }],
  }),
  component: PortfolioPage,
});

type Category = "All" | "Interior" | "Exterior" | "POP" | "Painting";

const projects: { src: string; title: string; cat: Exclude<Category, "All">; location: string }[] = [
  { src: project1, title: "Decorative Dining Room", cat: "Interior", location: "Abuja" },
  { src: project2, title: "Office Reception", cat: "Painting", location: "Lagos" },
  { src: project3, title: "Master Bedroom Suite", cat: "Interior", location: "Port Harcourt" },
  { src: project4, title: "Living Room POP", cat: "POP", location: "Lagos" },
  { src: project5, title: "Residential Exterior", cat: "Exterior", location: "Ibadan" },
  { src: project6, title: "Restaurant Interior", cat: "POP", location: "Enugu" },
];

const categories: Category[] = ["All", "Interior", "Exterior", "POP", "Painting"];

function PortfolioPage() {
  const [active, setActive] = useState<Category>("All");
  const filtered = active === "All" ? projects : projects.filter((p) => p.cat === active);

  return (
    <div>
      <section className="border-b border-border bg-secondary">
        <div className="mx-auto max-w-7xl px-4 py-16 md:px-6 md:py-24">
          <p className="text-sm font-bold uppercase tracking-[0.2em] text-accent">Portfolio</p>
          <h1 className="mt-2 text-4xl font-black tracking-tight text-foreground md:text-5xl">
            Finishing work we're proud of.
          </h1>
          <p className="mt-4 max-w-2xl text-muted-foreground">
            Homes, offices, restaurants, and exteriors — a snapshot of recent
            Kurama projects delivered across Nigeria.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-12 md:px-6 md:py-16">
        <div className="flex flex-wrap gap-2">
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setActive(c)}
              className={`rounded-full px-4 py-2 text-sm font-semibold transition-colors ${
                active === c
                  ? "bg-primary text-primary-foreground"
                  : "border border-border bg-card text-foreground hover:bg-secondary"
              }`}
            >
              {c}
            </button>
          ))}
        </div>

        <div className="mt-8 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {filtered.map((p) => (
            <figure
              key={p.title}
              className="group relative overflow-hidden rounded-xl border border-border bg-card"
            >
              <img
                src={p.src}
                alt={p.title}
                loading="lazy"
                className="aspect-[4/3] h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <figcaption className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-primary/95 via-primary/60 to-transparent p-4 text-primary-foreground">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <p className="text-sm font-extrabold">{p.title}</p>
                    <p className="text-xs text-primary-foreground/70">{p.location}</p>
                  </div>
                  <span className="rounded-full bg-accent px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-accent-foreground">
                    {p.cat}
                  </span>
                </div>
              </figcaption>
            </figure>
          ))}
        </div>

        <div className="mt-14 flex flex-col items-center gap-4 rounded-2xl bg-primary p-10 text-center text-primary-foreground">
          <h3 className="text-2xl font-black md:text-3xl">Have a project in mind?</h3>
          <Link
            to="/contact"
            className="inline-flex items-center gap-2 rounded-md bg-accent px-6 py-3 text-sm font-bold text-accent-foreground"
          >
            Start a Project <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>
    </div>
  );
}