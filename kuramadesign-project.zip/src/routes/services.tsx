import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, CheckCircle2 } from "lucide-react";
import servicePop from "../assets/service-pop.jpg";
import servicePainting from "../assets/service-painting.jpg";
import serviceScreeding from "../assets/service-screeding.jpg";
import serviceWallpaper from "../assets/service-wallpaper.jpg";
import serviceExterior from "../assets/service-exterior.jpg";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Services — Kurama Interior & Exterior Finishing" },
      {
        name: "description",
        content:
          "Wall screeding, POP ceiling installation, painting, wallpaper installation, and general building finishing across Nigeria.",
      },
      { property: "og:title", content: "Services — Kurama Finishing" },
      {
        property: "og:description",
        content:
          "Full-service interior and exterior finishing: screeding, POP, painting, wallpaper, and more.",
      },
      { property: "og:url", content: "/services" },
    ],
    links: [{ rel: "canonical", href: "/services" }],
  }),
  component: ServicesPage,
});

const services = [
  {
    title: "Wall Screeding",
    img: serviceScreeding,
    desc: "We level and smooth walls with precision-mixed screed so every surface is paint-ready, durable, and free of cracks or unevenness.",
    points: ["Crack-resistant finish", "Perfectly flat surfaces", "Ready for paint or wallpaper"],
  },
  {
    title: "POP Ceiling Installation",
    img: servicePop,
    desc: "Custom plaster of paris ceilings — from clean cove designs to intricate decorative patterns — installed with concealed lighting.",
    points: ["Custom designs", "Concealed lighting integration", "Clean, durable installation"],
  },
  {
    title: "Interior & Exterior Painting",
    img: servicePainting,
    desc: "Premium painting with proper surface prep, primer, and finish coats. Even coverage, sharp edges, and long-lasting color.",
    points: ["Surface prep + priming", "Premium emulsion & textured paint", "Flawless edges"],
  },
  {
    title: "Wallpaper Installation",
    img: serviceWallpaper,
    desc: "Precise wallpaper installation — pattern-aligned, no bubbles, no peeling seams. From feature walls to full rooms.",
    points: ["Pattern matching", "Bubble-free finish", "Wide range of wallpaper types"],
  },
  {
    title: "General Building Finishing",
    img: serviceExterior,
    desc: "Complete finishing for new builds and renovations — interior and exterior coordination from screeding through final paint.",
    points: ["Full project coordination", "Interior & exterior coverage", "Renovation & new construction"],
  },
];

function ServicesPage() {
  return (
    <div>
      <section className="border-b border-border bg-secondary">
        <div className="mx-auto max-w-7xl px-4 py-16 md:px-6 md:py-24">
          <p className="text-sm font-bold uppercase tracking-[0.2em] text-accent">Our Services</p>
          <h1 className="mt-2 text-4xl font-black tracking-tight text-foreground md:text-5xl">
            Finishing services for every space.
          </h1>
          <p className="mt-4 max-w-2xl text-muted-foreground">
            From bare walls to a beautifully finished room — we handle every
            stage of interior and exterior finishing across Nigeria.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 md:px-6 md:py-20">
        <div className="grid gap-10">
          {services.map((s, i) => (
            <article
              key={s.title}
              className={`grid gap-8 overflow-hidden rounded-2xl border border-border bg-card p-2 md:grid-cols-2 md:p-4 ${
                i % 2 ? "md:[&>div:first-child]:order-2" : ""
              }`}
            >
              <div className="overflow-hidden rounded-xl">
                <img
                  src={s.img}
                  alt={s.title}
                  loading="lazy"
                  className="aspect-[4/3] h-full w-full object-cover"
                />
              </div>
              <div className="flex flex-col justify-center p-4 md:p-8">
                <h2 className="text-2xl font-black tracking-tight text-card-foreground md:text-3xl">
                  {s.title}
                </h2>
                <p className="mt-3 text-muted-foreground">{s.desc}</p>
                <ul className="mt-5 space-y-2">
                  {s.points.map((p) => (
                    <li key={p} className="flex items-start gap-2 text-sm font-medium text-card-foreground">
                      <CheckCircle2 className="mt-0.5 h-4 w-4 text-accent" /> {p}
                    </li>
                  ))}
                </ul>
              </div>
            </article>
          ))}
        </div>

        <div className="mt-14 flex flex-col items-center gap-4 rounded-2xl bg-primary p-10 text-center text-primary-foreground">
          <h3 className="text-2xl font-black md:text-3xl">Not sure where to start?</h3>
          <p className="max-w-xl text-primary-foreground/70">
            Send us a few details about your space and timeline — we'll
            recommend the right finishing approach and budget.
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center gap-2 rounded-md bg-accent px-6 py-3 text-sm font-bold text-accent-foreground"
          >
            Talk to Us <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>
    </div>
  );
}