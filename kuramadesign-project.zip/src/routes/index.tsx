import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, CheckCircle2, Hammer, Sparkles, Clock, ShieldCheck } from "lucide-react";
import heroImage from "../assets/hero-interior.jpg";
import servicePop from "../assets/service-pop.jpg";
import servicePainting from "../assets/service-painting.jpg";
import serviceScreeding from "../assets/service-screeding.jpg";
import serviceWallpaper from "../assets/service-wallpaper.jpg";
import project1 from "../assets/project-1.jpg";
import project2 from "../assets/project-2.jpg";
import project3 from "../assets/project-3.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Kurama Finishing — Interior & Exterior Finishing in Nigeria" },
      {
        name: "description",
        content:
          "Premium wall screeding, POP ceilings, painting, wallpaper, and building finishing across Nigeria. Clean, durable, on-time delivery.",
      },
      { property: "og:title", content: "Kurama Finishing — Interior & Exterior Finishing" },
      {
        property: "og:description",
        content:
          "Premium finishing services for homes, contractors, and businesses across Nigeria.",
      },
      { property: "og:url", content: "/" },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  return (
    <div>
      {/* HERO */}
      <section className="relative overflow-hidden bg-primary text-primary-foreground">
        <div className="absolute inset-0">
          <img
            src={heroImage}
            alt="Premium interior finishing with POP ceiling and cove lighting"
            width={1600}
            height={1024}
            className="h-full w-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-primary via-primary/85 to-primary/40" />
        </div>
        <div className="relative mx-auto grid max-w-7xl gap-10 px-4 py-20 md:grid-cols-2 md:px-6 md:py-32">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full border border-accent/40 bg-accent/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-accent">
              <Sparkles className="h-3.5 w-3.5" /> Finishing Specialists · Nigeria
            </span>
            <h1 className="mt-5 text-4xl font-black leading-[1.05] tracking-tight md:text-6xl">
              Clean, durable finishing that{" "}
              <span className="text-accent">elevates every space.</span>
            </h1>
            <p className="mt-5 max-w-xl text-base text-primary-foreground/80 md:text-lg">
              Kurama delivers professional wall screeding, POP ceilings, painting,
              wallpaper, and complete building finishing — on site, across every
              state in Nigeria.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 rounded-md bg-accent px-5 py-3 text-sm font-bold text-accent-foreground transition-transform hover:scale-[1.02]"
              >
                Request a Quote <ArrowRight className="h-4 w-4" />
              </Link>
              <Link
                to="/portfolio"
                className="inline-flex items-center gap-2 rounded-md border border-primary-foreground/30 px-5 py-3 text-sm font-semibold text-primary-foreground hover:bg-primary-foreground/10"
              >
                View Our Work
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* TRUST STRIP */}
      <section className="border-b border-border bg-background">
        <div className="mx-auto grid max-w-7xl gap-6 px-4 py-10 md:grid-cols-4 md:px-6">
          {[
            { icon: CheckCircle2, label: "Neat, precise finishing" },
            { icon: Clock, label: "On-time project delivery" },
            { icon: ShieldCheck, label: "Durable, long-lasting work" },
            { icon: Hammer, label: "Skilled, trusted craftsmen" },
          ].map(({ icon: Icon, label }) => (
            <div key={label} className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-md bg-accent/15 text-accent">
                <Icon className="h-5 w-5" />
              </span>
              <span className="text-sm font-semibold text-foreground">{label}</span>
            </div>
          ))}
        </div>
      </section>

      {/* SERVICES */}
      <section className="mx-auto max-w-7xl px-4 py-20 md:px-6">
        <div className="flex items-end justify-between gap-6">
          <div>
            <p className="text-sm font-bold uppercase tracking-[0.2em] text-accent">What we do</p>
            <h2 className="mt-2 text-3xl font-black tracking-tight text-foreground md:text-4xl">
              Finishing services, done right.
            </h2>
          </div>
          <Link
            to="/services"
            className="hidden text-sm font-semibold text-foreground hover:text-accent md:inline-flex"
          >
            See all services →
          </Link>
        </div>

        <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {[
            { img: serviceScreeding, title: "Wall Screeding", desc: "Perfectly smooth walls ready for paint or wallpaper." },
            { img: servicePop, title: "POP Ceilings", desc: "Custom plaster of paris designs and clean installations." },
            { img: servicePainting, title: "Painting", desc: "Interior and exterior painting with flawless coverage." },
            { img: serviceWallpaper, title: "Wallpaper", desc: "Precise wallpaper installation, no bubbles or seams." },
          ].map((s) => (
            <div
              key={s.title}
              className="group overflow-hidden rounded-lg border border-border bg-card transition-shadow hover:shadow-[var(--shadow-elegant)]"
            >
              <div className="aspect-[4/3] overflow-hidden">
                <img
                  src={s.img}
                  alt={s.title}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <div className="p-5">
                <h3 className="text-lg font-extrabold text-card-foreground">{s.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{s.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* WHY US */}
      <section className="bg-secondary">
        <div className="mx-auto grid max-w-7xl gap-12 px-4 py-20 md:grid-cols-2 md:px-6">
          <div>
            <p className="text-sm font-bold uppercase tracking-[0.2em] text-accent">Why Kurama</p>
            <h2 className="mt-2 text-3xl font-black tracking-tight text-foreground md:text-4xl">
              Built on craftsmanship, trust, and timely delivery.
            </h2>
            <p className="mt-4 text-muted-foreground">
              We work with homeowners, contractors, and businesses across Nigeria.
              Every project is treated like our own — from preparation to the final
              coat — because finishing is what people see and live with every day.
            </p>
            <Link
              to="/about"
              className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-foreground hover:text-accent"
            >
              Learn about us <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <ul className="grid gap-4">
            {[
              "Honest pricing with no hidden costs",
              "Experienced team, properly equipped",
              "Premium materials sourced locally",
              "Service available in every state in Nigeria",
              "Strict cleanup — we leave sites neat",
            ].map((point) => (
              <li
                key={point}
                className="flex items-start gap-3 rounded-lg border border-border bg-card p-4"
              >
                <CheckCircle2 className="mt-0.5 h-5 w-5 flex-shrink-0 text-accent" />
                <span className="text-sm font-medium text-card-foreground">{point}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* FEATURED PROJECTS */}
      <section className="mx-auto max-w-7xl px-4 py-20 md:px-6">
        <div className="flex items-end justify-between gap-6">
          <div>
            <p className="text-sm font-bold uppercase tracking-[0.2em] text-accent">Recent work</p>
            <h2 className="mt-2 text-3xl font-black tracking-tight text-foreground md:text-4xl">
              A glimpse of our finishing.
            </h2>
          </div>
          <Link to="/portfolio" className="hidden text-sm font-semibold hover:text-accent md:inline-flex">
            Full portfolio →
          </Link>
        </div>
        <div className="mt-10 grid gap-4 md:grid-cols-3">
          {[project1, project2, project3].map((src, i) => (
            <div key={i} className="overflow-hidden rounded-lg">
              <img
                src={src}
                alt={`Featured project ${i + 1}`}
                loading="lazy"
                className="aspect-[4/3] h-full w-full object-cover transition-transform duration-500 hover:scale-105"
              />
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-4 pb-10 md:px-6">
        <div className="overflow-hidden rounded-2xl bg-primary p-10 text-primary-foreground md:p-14">
          <div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-center">
            <div>
              <h2 className="text-2xl font-black tracking-tight md:text-3xl">
                Ready to start your finishing project?
              </h2>
              <p className="mt-2 text-primary-foreground/70">
                Tell us about your space — we'll get back with a clear plan and quote.
              </p>
            </div>
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 rounded-md bg-accent px-6 py-3 text-sm font-bold text-accent-foreground hover:scale-[1.02] transition-transform"
            >
              Get a Quote <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
