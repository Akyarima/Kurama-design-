## Kurama Interior & Exterior Finishing — Website Plan

A bold, professional multi-page marketing site showcasing Kurama's finishing services across Nigeria.

### Pages (separate routes for SEO)

1. **Home** (`/`) — Hero with strong headline ("Clean, Durable Finishing Across Nigeria"), service highlights, why-choose-us strip, featured projects, testimonial preview, CTA to contact.
2. **Services** (`/services`) — Detailed cards for: Wall Screeding, POP Ceiling Installation, Painting, Wallpaper Installation, General Building Finishing. Each with description, benefits, and process.
3. **Portfolio** (`/portfolio`) — Grid gallery of finished projects with category filters (Interior / Exterior / POP / Painting). Lightbox-style hover details.
4. **Testimonials** (`/testimonials`) — Client quotes from homeowners, contractors, and businesses with project context.
5. **About** (`/about`) — Company story, mission, values (quality, neat finishing, timely delivery), service coverage across Nigeria.
6. **Contact** (`/contact`) — Contact form, WhatsApp/phone CTA, email, service-area note, optional embedded map placeholder.

### Design direction — Bold & professional

- **Palette**: Deep charcoal/near-black + warm construction amber/orange accent + clean white surfaces. Conveys craftsmanship + premium finishing.
- **Typography**: Strong display sans for headings (confident, slightly condensed) + clean readable sans for body.
- **Visual style**: Large hero imagery, generous section padding, bold section headers with accent underlines, card-based service grid, before/after-style image treatments in portfolio.
- **Imagery**: AI-generated placeholder images of interior finishing, POP ceilings, painted walls, wallpaper installations — you can swap them later with real project photos.

### Tech & structure

- TanStack Start file-based routes under `src/routes/`.
- Shared header (logo + nav: Home, Services, Portfolio, Testimonials, About, Contact) and footer (contact info, service list, social) in `__root.tsx`.
- Semantic design tokens defined in `src/styles.css` (oklch); shadcn components themed accordingly.
- Each route gets unique `head()` metadata (title, description, og tags) for SEO.
- Responsive (mobile-first), since current viewport is mobile.
- Contact form is presentational for now (no backend); we can wire it to Lovable Cloud later if you want submissions saved/emailed.

### Out of scope (for now)

- No backend, database, or authentication.
- No real project photos — placeholders generated; you can replace later.
- No booking/quote-request backend (form is UI only until you ask).

Ready to build when you approve.